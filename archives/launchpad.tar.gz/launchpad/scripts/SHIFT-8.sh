send_string '*' 'DEL'
