send_string '(' 'DEL'
