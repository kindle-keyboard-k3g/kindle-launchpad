send_string '!' 'DEL'
