send_string '@' 'DEL'
