send_string '#' 'DEL'
