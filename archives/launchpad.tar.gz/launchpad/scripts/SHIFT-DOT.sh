send_string ',' 'DEL'
