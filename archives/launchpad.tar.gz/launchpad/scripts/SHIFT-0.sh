send_string ')' 'DEL'
