send_string '$' 'DEL'
